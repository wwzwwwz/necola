package com.example.necola.ViewHolder;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MsgViewHolder extends RecyclerView.ViewHolder{


    public MsgViewHolder(@NonNull View itemView) {
        super(itemView);

    }

}
